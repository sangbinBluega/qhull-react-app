////////////////////////////////////////////////////////////////////////////////
//  tsQhull

window.tsQhull = window.tsQhull || {_cfg:{}}

/*  storage
        course
    resolver
        course
        qsetUi
    listener
        sensor
    ui
        qsetRatio: Float, Qset 실행창 Ratio. 가로 기준 세로 비율. 없으면 저작기의 기본값으로 그냥 표시
        title: String, TOOL 명칭
*/
tsQhull.set = function(/*String*/group, /*String*/key, value)
{
    this._cfg[group] = this._cfg[group] || {};
    this._cfg[group][key] = value;
}

tsQhull.get = function(/*String*/group, /*String*/key)/*Value|undefined*/
{
    if (this._cfg[group]) return this._cfg[group][key];
}

tsQhull.init = function(onSucc, onErr)
{
    var _this = this;

    this._cfg.storage.course.call(this, function (/*{}*/course){
            _this.course = course;

            //  차시모들의 Content 정보에 차시 ID를 넣어 줍니다. 이것은 QSET 호출 정보를 위한 것입니다.
            function traverse(node, depth)
            {
                if (node.childNode && node.childNode.length){
                    for(var i = 0; i < node.childNode.length; i ++){
                        if (depth == 2){ // 차시이면
                            if (node.childNode[i].Content) node.childNode[i].Content.idLesson = node.Id;
                        }
                        traverse(node.childNode[i], depth + 1);
                    }
                }
            }
            traverse(course, 0);

            if (onSucc) onSucc();
        }
        ,function(err){
            if (onErr) onErr(Err);
        }
    );

    //  Listener-sensor
    window.addEventListener('message', function(ev){
        function escapeHTML(text)
        {
          return (text+'').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/\'/g, '&apos;').replace(/\"/g, '&quot;').replace(/>/g, '&gt;');
        }

        if (ev.data && ev.data.mqf && ev.data.mqf.event == 'onSensor'){
            if (_this._cfg.listener && _this._cfg.listener.sensor){
                var sensor = ev.data.mqf.data;
                var msg = '<div style="color:yellow;">[Sensor] ' + sensor.Sensor + '</div>';

                msg += '<div style="padding-left:1em;"><span style="color:yellow;">[Data]</span> ' + escapeHTML(JSON.stringify(sensor.Data)) + '</div>';
                if (sensor.where) msg += '<div style="padding-left:1em;"><span style="color:yellow;">[Where]</span>' + escapeHTML(JSON.stringify(sensor.where)) + '</div>';

                _this._cfg.listener.sensor.call(_this, msg);
            }
        }
    }, false);
}

tsQhull.getContentURI = function(node)
{
    var uri = '', param;

    if (node.Content){ console.error(node.Content)
        if (node.Content.Type == 'qset' && node.Content.Id && node.Content.IdQsetUi){
            uri = this._cfg.resolver.qsetUi.call(this, node.Content.IdQsetUi);
            param = 'QSET='+encodeURIComponent(node.Content.Id)+'&QLESSON='+encodeURIComponent(node.Content.idLesson);

            if (uri.indexOf('?') != -1) uri += '&'+param;
            else uri += '?'+param;

            uri += '&QTRACE=Y';
        }
        else{
            console.error('Error content type');
        }
    }

    return uri;
}
