tsQhull.set('storage', 'course', eccCourseLoad);
tsQhull.set('resolver', 'course', eccCourseResolve);
tsQhull.set('resolver', 'qsetUi', eccQsetUiResolve);

tsQhull.set('ui', 'title', 'iLearning | 서비스 구조 실행기');
tsQhull.set('ui', 'titleLogo', 'db/titleLogo.png');
tsQhull.set('ui', 'contentRatio', '0.5625'); // 720/1280